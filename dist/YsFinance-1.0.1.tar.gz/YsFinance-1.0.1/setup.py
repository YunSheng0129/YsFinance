from setuptools import setup, find_packages

setup(
    name='YsFinance',
    version='1.0.1',
    author='YunSheng',
    author_email='278211638@qq.com',
    description='About finance',
    # url='https://github.com/YunSheng0129/YsFinance.git',
    packages=find_packages(),
    # install_requires=['dependency1', 'dependency2'],  # 依赖列表
)